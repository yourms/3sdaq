from django.shortcuts import render, redirect

# Create your views here.




def index(request) :
   return render(request, 'index2.html')

def login(request) :
    return render(request, 'login2.html')



# 여기에서 sqlite 값 가져오면 될듯? ?
def charts(request) :
    installation = [3068, 2970, 2839, 2977, 2663 , 2665 ]
    context = {
        'installation' : installation
    }
    return render(request,  'charts.html', context)